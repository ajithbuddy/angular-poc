import { Component, Input, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { saveAs } from 'file-saver';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'file_upload';
  format = "";
  showUsers:boolean = true;
  selectedUser:any;

  @ViewChild('myForm', { static: true }) myForm: any;

  displayStyle = "none";
  users = [{name:"aji",age:25},{name:"suji",age:26},{name:"kavin",age:27}];
  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  onSubmit(format:any) {
    console.log(format);
    this.download(format);
  }

  createDocFile(keyCode: number){

    // var textAreaLength = this.myForm.form.value.myText.length;
    // if(keyCode != 8){
    //   if(textAreaLength == 1){
    //     var file = new Blob([""], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    //     // openfile(file);
    //     saveAs(file, "downloadbytyping.docx"); //first method for download files     
    //   }

    // }
  }

  download(format:any) {
    // var FileSaver = require('file-saver'); //first method for download files
    var file = new Blob([this.myForm.form.value.myText], { type: format });
    // openfile(file);
    // saveAs(file, "hello world.docx"); //first method for download files
    const nav = (window.navigator as any);
    // console.log(nav.msSaveOrOpenBlob);
    if (nav.msSaveOrOpenBlob) {
      // console.log("in if part");
      nav.msSaveOrOpenBlob(file, this.myForm.form.value.filename);
    }
    else {
      // Others
      //second method
      var a = document.createElement('a'),
      url = URL.createObjectURL(file);
      a.href = url;
      a.download = "download";
      document.body.appendChild(a);
      a.click();
      // setTimeout(function () {
      //   document.body.removeChild(a);
      //   window.URL.revokeObjectURL(url);
      // }, 0);  
    }
  }
}
// function openfile(file: Blob) {
//   throw new Error('Function not implemented.');
// }

